from flask import Flask,redirect,url_for,render_template,request,flash
from flask_sqlalchemy import SQLAlchemy
# the above we import request also
   
app = Flask(__name__) 
# app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///mysql.sqlite3'
# #app.config is a Flask variable
# db=SQLAlchemy(app)
			

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydb.sqlite3'  
  
db = SQLAlchemy(app)  
  
class Sample(db.Model):  #here insted of db we put any one
   id = db.Column( db.Integer, primary_key = True)  
   name = db.Column(db.String(100)) 
   fathername = db.Column(db.String(100))
   rollno=db.Column(db.String(100))
   emailid = db.Column(db.String(50))  
   mobileno = db.Column(db.String(200))   
  
  
   def __init__(self, name,fathername,rollno,emailid, mobileno):  
      self.name = name  
      self.fathername=fathername
      self.rollno=rollno
      self.emailid = emailid  
      self.mobileno = mobileno 
@app.route('/mypage/show')  
def show():
	data=Sample.query.all()
	#return render_template('log.html',data=data)
	return render_template('showlist.html',data=data)
	# sm=sample(name=fname,fathername=faname,rollno=rollno,emailid=emailid,mobileno=mobileno)


  
@app.route('/admin')  
def admin():  
    return '<h1> This is admin page </h1>'  
  

  
@app.route('/student')  
def student():  
    return '<h3>This is student page </h3>'  
  
@app.route('/user/<name>')  
def user(name):  
    if name == 'admin':  
        return redirect(url_for('admin'))  
     
    if name == 'student':  
        return redirect(url_for('student')) 

@app.route('/myhtml/<name>')
def myhtml1(name):
	return render_template("register.html",name1=name)
@app.route('/mypage/register',methods=['GET','POST'])
#when we click this url then its display resgister form
def register():
	if request.method=='POST':
		#values =request.form[] #-->it is display all values
		#data=request.form[]#-->variable change
		#name=data['faname']#--> It is directly used insted of request.form
		name=request.form['fname']#it is display particular field
		fathername=request.form['faname']
		rollno=request.form['rollno']
		mailid=request.form['emailid']
		phno=request.form['mobileno']
		#print(name,mailid,phno)
		sm=Sample(name,fathername,rollno,mailid,phno)
		db.session.add(sm)
		db.session.commit()
		return '<h1>Record stored</h1>'
		#flash("Registration completed,you can login")#after db connection and before render
		#return render_template('log.html',na=name,fa=fathername,roll=rollno,mail=mailid,ph=phno)
		return render_template('showlist.html',na=name,fa=fathername,roll=rollno,mail=mailid,ph=phno)
	flash("U can register now")
	return render_template('register.html')
# @app.route('/mypage/show')
# def show():
# 	data=Sample.query.all()
# 	return render_template('showlist.html',data=data)

if __name__ =='__main__': 
	app.secret_key="my key"
	db.create_all()
	app.run(debug = True)
