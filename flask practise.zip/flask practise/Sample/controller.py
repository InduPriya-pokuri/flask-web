# from flask import Flask     ------here flask is some times folder and
# some times it is a class---- app=Flask(__name__)
# @app.route('/welcome/<name>/<int:rollno>/') #--here we gave name place
# any name in url def msg(name,rollno):     return "<h2>welcome  "
# +name+  "<br> This is your rollno " +str(rollno)+'</h2>'



# if __name__=="__main__":   #-----meaning is our py file is check it is user defined file or  
# 	app.run(debug=True)  #---get the controller name and send iit into flask ---



# from flask import Flask,redirect,url_for   # we didnt want these seperate url just ude star
# app=Flask(__name__)
# @app.route('/') #here we gave name place any name in url
# def msg():
# 	return "<h2>welcome To python lab </h2>"
# @app.route('/home')
# def home():
# 	return redirect(url_for('msg'))


# if __name__=="__main__":
# 	app.run(debug=True)


# from flask import *   # we didnt want these seperate url just use star
# app=Flask(__name__)
# @app.route('/<name>') #here we gave name place any name in url
# def msg(name):
# 	return "welcome  "+name 
# @app.route('/home')
# def home():
# 	return redirect(url_for('msg',name="Indupriya"))


# if __name__=="__main__":
# 	app.run(debug=True) ##it is used to run all the items which we r update server will reload not broweser


# Flask url building
####################

# from flask import Flask,redirect,url_for,render_template
   
# app = Flask(__name__)  
  
# @app.route('/admin')  
# def admin():  
#     return '<h1> This is admin page </h1>'  
  
# @app.route('/librarion')  
# def librarion():  
#     return ' <h2>This is librarion page <h2>'   
  
# @app.route('/student')  
# def student():  
#     return '<h3>This is student page </h3>'  
  
# @app.route('/user/<name>')  
# def user(name):  
#     if name == 'admin':  
#         return redirect(url_for('admin'))  
#     if name == 'librarion':  
#         return redirect(url_for('librarion'))  
#     if name == 'student':  
#         return redirect(url_for('student')) 
# @app.route('/myhtml')
# def myhtml():
# 	return render_template("sample.html")
# @app.route('/myhtml/<name>')
# def myhtml1(name):
# 	return render_template("sample.html",name1=name)
# @app.route('/mypage/register')#when we click this url then its display resgister form
# def register():
# 	return render_template('register.html')
# @app.route('/mypage/login')
# def login():
# 	return render_template('login.html')
# @app.route('/mypage/login1')
# def login1():
# 	return render_template('login1.html')

# if __name__ =='__main__':  
#     app.run(debug = True)



from flask import Flask,redirect,url_for,render_template,request,flash
from flask_sqlalchemy import SQLAlchemy
# the above we import request also
   
app = Flask(__name__) 
# app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///mysql.sqlite3'
# #app.config is a Flask variable
# db=SQLAlchemy(app)
			

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydb.sqlite3'  
  
db = SQLAlchemy(app)  
  
class Sample(db.Model):  #here insted of db we put any one
   id = db.Column( db.Integer, primary_key = True)  
   name = db.Column(db.String(100))  
   emailid = db.Column(db.Float(50))  
   mobileno = db.Column(db.String(200))   
  
  
   def __init__(self, name, emailid, mobileno):  
      self.name = name  
      self.emailid = emailid  
      self.mobileno = mobileno 
@app.route('/mypage/show')  
def show():
	data=Sample.query.all()
	return render_template('showlist.html',data=data)


  
@app.route('/admin')  
def admin():  
    return '<h1> This is admin page </h1>'  
  
@app.route('/librarion')  
def librarion():  
    return ' <h2>This is librarion page <h2>'   
  
@app.route('/student')  
def student():  
    return '<h3>This is student page </h3>'  
  
@app.route('/user/<name>')  
def user(name):  
    if name == 'admin':  
        return redirect(url_for('admin'))  
    if name == 'librarion':  
        return redirect(url_for('librarion'))  
    if name == 'student':  
        return redirect(url_for('student')) 
@app.route('/myhtml')
def myhtml():
	return render_template("sample.html")
@app.route('/myhtml/<name>')
def myhtml1(name):
	return render_template("sample.html",name1=name)
@app.route('/mypage/register',methods=['GET','POST'])
#when we click this url then its display resgister form
def register():
	if request.method=='POST':
		#values=request.form[] #-->it is display all values
		name=request.form['fname'] #it is display particular field
		mailid=request.form['emailid']
		phno=request.form['mobileno']
		#print(name,mailid,phno)
		flash("Registration completed,you can login")#after db connection and before render
		return render_template('login1.html')
	flash("U can register now")
	return render_template('register.html')
@app.route('/mypage/login')
def login():
	return render_template('login.html')
@app.route('/mypage/login1')
def login1():
	return render_template('login1.html')

if __name__ =='__main__': 
	app.secret_key="my key"
	db.create_all()
	app.run(debug = True)
