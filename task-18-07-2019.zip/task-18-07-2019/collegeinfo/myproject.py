from flask import Flask,render_template,url_for,request#step1
#url_for is used to navigate the page

from flask_sqlalchemy import SQLAlchemy
#object for flask class
app=Flask(__name__)#step:2
#the below line is mandatory name
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///collegeinfo.sqlite3' 
#app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///collegeinfo.db'#...any one given
mydb=SQLAlchemy(app)
class Signup(mydb.Model):#but in db table class name is in small letters
	id=mydb.Column(mydb.Integer,primary_key=True)
	s_name=mydb.Column(mydb.String(200))
	roll_no=mydb.Column(mydb.String(50))
	mail_id=mydb.Column(mydb.String(200))
	#password=mydb.Column(mydb.String(200))
	phone_no=mydb.Column(mydb.String(50))
	branch=mydb.Column(mydb.String(100))

	# To call a function
	#and these values are temporary values
	def __init__(self,name,rollno,emailid,phno,branch):
		self.s_name=name
		self.roll_no=rollno
		self.mail_id=emailid
		self.phone_no=phno
		self.branch=branch


#here get is mandatory and POST is our purpose
@app.route('/myportal/signup',methods=['POST','GET'])#st:5 #-->Method will display after the html write in method
def signup():
	#Checking the method is POST or GET
	if request.method=="POST":
		data=request.form  #to retrive details
		#print(data) #to check if data is displayed or not in server i.e..,Command prompt
		#
		stu_name=data['sname']# right side names are these names are in server names i.e.., keys
		stu_rollno=data['rollno']
		stu_mailid=data['email']
		#stu_pwd=data['pswd']
		stu_phno=data['phno']
		stu_branch=data['branch']
		#print(stu_name,stu_rollno,stu_mailid,stu_pwd,stu_phno,stu_branch)  #-->server check
        # After reading values 
        #these values are stored in database
		sgn=Signup(stu_name,stu_rollno,stu_mailid,stu_phno,stu_branch)
		mydb.session.add(sgn)
		mydb.session.commit()
		return render_template('status.html')#just to confirm success
	return render_template('signup.html')#to show only signup page and we import render_template

#now we need to create template folder to store all html files
@app.route('/myportal/showList')
def display():
	data=Signup.query.all()
	return render_template('showDetails.html',data=data)

#
if __name__=="__main__":#step:3
	mydb.create_all()# To create in db 
	app.run(debug=True) # step :4 #host=127.0.0.0 and port:5000



